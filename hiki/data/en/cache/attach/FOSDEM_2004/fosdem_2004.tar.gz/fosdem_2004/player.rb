require 'libglade2'
require 'gst'

class Player
	def initialize
		xml = GladeXML.new('player.glade') { |handler| method(handler) }
		
		src = Gst::ElementFactory.make("filesrc", "source")
		dec = Gst::ElementFactory.make("spider")
		sink = Gst::ElementFactory.make("osssink")
		src >> dec >> sink
		
		@pipeline = Gst::Thread.new
		@pipeline.add(src, dec, sink)

		@window = xml['my_window']
	end

	def on_play
		@pipeline.play
	end

	def on_stop
		@pipeline.stop
	end

	def on_pause
		@pipeline.pause
	end

	def on_eject
		dialog = Gtk::FileSelection.new("Select a file to play")
		if dialog.run == Gtk::Dialog::RESPONSE_OK
			@pipeline["source"].location = dialog.filename
			@window.title = "Playing " + dialog.filename
			on_play
		end
		dialog.destroy
	end

	def on_destroy
		Gtk.main_quit
	end
end

Gst.init
Gtk.init
Player.new
Gtk.main
