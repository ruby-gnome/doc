#!/usr/bin/env ruby
#
# This file is gererated by ruby-glade-create-template 1.1.1.
#
# $Id: pkgconfigviewerglade.rb,v 1.1.1.1 2005/08/02 16:54:26 mutoh Exp $
#
require 'libglade2'

# Support L10n (Requires RAA:Ruby-GetText-Package)
begin
  require 'gettext'
rescue LoadError
  unless defined? GetText
    module GetText
      module_function
      def _(msgid); msgid; end
      def N_(msgid); msgid; end
      def n_(msgid, msgid_plural, n)
	msgid
      end
      def s_(msgid, div = '|')
	if index = msgid.rindex(div)
	  msgid = msgid[(index + 1)..-1]
	else
	  msgid
	end
      end
      def bindtextdomain(domainname, path = nil, locale = nil, charset = nil)
      end
    end
  end
end

class PkgconfigviewerGlade
  include GetText
  
  def initialize(path_or_data, root = nil, domain = nil, localedir = nil, flag = GladeXML::FILE)
    GetText.bindtextdomain(domain, localedir, nil, "UTF-8")
    @glade = GladeXML.new(path_or_data, root, domain, localedir, flag) {|handler| method(handler)}
    
  end
  
  def on_listview_cursor_changed(widget)
    puts "on_listview_cursor_changed() is not implemented yet."
  end
  def on_window_quit(widget)
    puts "on_window_quit() is not implemented yet."
  end
  def on_about_activate(widget)
    puts "on_about_activate() is not implemented yet."
  end
end

# Main program
if __FILE__ == $0
  # Set values as your own application. 
  PROG_PATH = "pkgconfigviewer.glade"
  PROG_NAME = "YOUR_APPLICATION_NAME"
  Gtk.init
  PkgconfigviewerGlade.new(PROG_PATH, nil, PROG_NAME)
  Gtk.main
end
