#!/usr/bin/env ruby
#
# Simple Audio Player 
#
# Copyright (c) 2003,2004 Laurent Sansonetti 
#
# You can redistribute it and/or modify it under the terms of
# the Ruby's licence.
#

require 'gnome2'
require 'gst'

class Playlist < Array 
    def initialize(files)
        super
        clear
        add_files(files) if files 
    end

    def add_file(file)
        unless File.exists?(file) and File.readable?(file)
            raise "file #{file} does not exist, or is not readable"
        end
       
        # Directory.
        if File.directory?(file)
            add_directory(file)
        # Playlist.
        elsif file =~ /\.list$/
            add_playlist(file)
        # Regular file.
        else
            push(file.gsub(/\/\//, "/"))
            uniq!
        end
    end

    def add_files(list)
        list.each { |x| add_file(x) }
    end

    def add_directory(dir)
        Dir.entries(dir).each do |x|
            next if x =~ /^\.{1,2}/   # ignore '.' and '..'
            x = dir + "/" + x
            add_file(x)
        end    
    end

    def add_playlist(file)
        contents = IO.readlines(file).collect do |x| 
            x.chomp unless x =~ /^#/
        end
        add_files(contents.compact)
    end
    
    def save(where)
        File.open(where, "w") { |file| each { |x| file.puts x } }
    end
end

class Player < Gtk::Window
    TITLE = "Simple Audio Player"
    NAME = "SimpleAudioPlayer" 
    VERSION = "0.1"

    class Action
        def initialize(descr, icon, &handler)
            @descr, @handler = descr, handler
            @source = [ icon.is_a?(String) ? "pixmaps/#{icon}.png" : icon, Gtk::IconSize::BUTTON ]
        end
        def to_button
            [ nil, @descr, nil, Gtk::Image.new(*@source), @handler ]
        end
        def to_menuitem
            item = Gtk::ImageMenuItem.new(@descr)
            item.image = Gtk::Image.new(*@source)
            item.signal_connect("activate") { @handler.call }
            item
        end
    end

    def initialize(files)
        # Initialize window.
        super(Gtk::Window::TOPLEVEL)
        self.resizable = false
        self.border_width = 5
        self.window_position = Gtk::Window::POS_CENTER
        self.title = TITLE
        accel_group = Gtk::AccelGroup.new
        add_accel_group(accel_group)
        
        # Initialize playlist.
        @playlist = Playlist.new(files)
        @current_track = @next_track = 0
        
        # Initialize pipeline.
        @pipeline = Gst::Thread.new
        @pipeline.signal_connect('eos') do
            @pipeline.stop
            stream
        end

        # Start the scaler timer.
        @timer = Gtk.timeout_add(1000) { timer; true }
        
        # Main actions.
        @actions = [ 
            Action.new("Previous track", "prev") { prev_track },
            Action.new("Play", "play") { play },
            Action.new("Pause", "pause") { pause },
            Action.new("Stop", "stop") { stop },
            Action.new("Next track", "next") { next_track },
            Action.new("Load new files..", "eject") { load_files },
            nil,
            Action.new("Show/hide playlist", Gtk::Stock::INDEX) { playlist },
            Action.new("About #{TITLE}...", Gnome::Stock::ABOUT) { about }
        ]
        
        # Initialize main toolbar with main actions (ignore the about dialog).
        toolbar = Gtk::Toolbar.new
        @actions[0..-2].each do |x| 
            x ? toolbar.append(*x.to_button) : toolbar.append_space
        end
      
        # Initialize the scaler.
        adjustment = Gtk::Adjustment.new(0.0,          # initial
                                         0.0,          # min
                                         1_000_000.0,  # max
                                         1.0,          # step_inc (unused)
                                         1.0,          # page_inc (unused)
                                         1.0)          # page_size (unused)
        @scaler = Gtk::HScale.new(adjustment)
        @scaler.draw_value = false
        @scaler.sensitive = true
        @seek_handler = @scaler.signal_connect('value_changed') { seek }
   
        # Playlist actions.
        @playlist_actions = [
            Action.new("Insert files in the playlist", Gtk::Stock::ADD) \
                       { load_files(false) },
            Action.new("Remove selection from playlist", Gtk::Stock::REMOVE) \
                       { remove_selected_track },
            Action.new("Clear playlist", Gtk::Stock::CLEAR) { clear_playlist },
            nil,
            Action.new("Load playlist", Gtk::Stock::OPEN) { load_files },
            Action.new("Save playlist", Gtk::Stock::SAVE) { save_playlist }
        ]
     
        # Initialize playlist toolbar with playlist actions.
        ptoolbar = Gtk::Toolbar.new
        @playlist_actions.each do |x| 
            x ? ptoolbar.append(*x.to_button) : ptoolbar.append_space
        end
     
        # Initialize playlist listview.
        @model = Gtk::ListStore.new(String, String)
        column = Gtk::TreeViewColumn.new("File",
                                         Gtk::CellRendererText.new,
                                         { :text => 0, :background => 1 })
        @listview = Gtk::TreeView.new(@model)
        @listview.append_column(column)
        @listview.headers_visible = false
        @listview.reorderable = true
        @listview.signal_connect("button_press_event") do |widget, ev|
            play_selected_track if (ev.button == 1 and ev.event_type == 5)
        end
        @listview.signal_connect('row_activated') { play_selected_track }
        @listview.add_accelerator('row_activated',
                                 accel_group,
                                 Gdk::Keyval::GDK_Return,
                                 0,
                                 Gtk::ACCEL_VISIBLE)
        refresh_playlist
     
        # Add playlist listview in a scrolled window.
        sw = Gtk::ScrolledWindow.new
        sw.height_request = 100
        sw.set_policy(Gtk::POLICY_NEVER, Gtk::POLICY_AUTOMATIC)
        sw.add(@listview)
     
        # Assemble all playlist-related widgets in a single box, which will
        # be shown/hidden accordingly.
        @playlist_box = Gtk::VBox.new
        @playlist_box.spacing = 5
        @playlist_box.pack_start(sw)
        @playlist_box.pack_start(Gtk::HSeparator.new, false)
        @playlist_box.pack_start(ptoolbar, false)

        # Assemble all other widget in a main box, and add-it to the window.
        box = Gtk::VBox.new
        box.spacing = 5
        box.pack_start(@scaler, false)
        box.pack_start(Gtk::HSeparator.new, false)
        box.pack_start(toolbar, false)
        box.pack_start(@playlist_box)
        add(box)
       
        # Handle window signals.
        signal_connect("destroy") do 
            stop
            Gtk.timeout_remove(@timer)
            Gtk.main_quit
            exit!
        end
        signal_connect("button_press_event") do |widget, ev|
            if ev.button == 3 
                popup_menu.popup(nil, nil, ev.button, ev.time) 
            end
        end
    end
    
    def show
        show_all
        @playlist_box.hide  # playlist is hidden by default
    end
   
    #######
    private
    #######
   
    # Player methods:
    # ---------------
  
    def play_track(n)
        unless @playlist.empty?
            @next_track = n
            (@pipeline.stopped?) ? stream : @pipeline.eos
        end
    end
   
    def play_selected_track
        if iter = @listview.selection.selected
            if i = @playlist.index(iter.get_value(0))
                play_track(i)
            end
        end
    end
    
    def prev_track
        n = @current_track - 1
        n = @playlist.length - 1 if n < 0
        play_track(n)
    end
    
    def next_track
        n = @current_track + 1
        n = 0 if n == @playlist.length
        play_track(n)
    end
    
    def play
        (@pipeline.paused?) ? @pipeline.play : play_track(0)
    end
    
    def pause
        @pipeline.pause if @pipeline.playing?
    end
    
    def stop
        unless @pipeline.stopped?
            @pipeline.stop 
            @current_track = @next_track = 0
        end
    end

    def stream
        # Create GStreamer elements.
        @filesrc = Gst::ElementFactory.make("filesrc")
        @filesrc.location = @playlist[@current_track]
        @spider = Gst::ElementFactory.make("spider")
        @audiosink = Gst::ElementFactory.make("osssink")
        
        # Link pads.
        @filesrc >> @spider >> @audiosink
        
        # Add element to the pipeline.
        @pipeline.clear
        @pipeline.add(@filesrc, @spider, @audiosink)
        @pipeline.play

        @current_track = @next_track
        refresh_playlist
    end
    
    def timer
        if @spider and n = @spider.query(Gst::QueryType::POSITION,
                                         Gst::Format::PERCENT) 
            # Block the 'value_changed' signal temporarily 
            # (it should only be emitted when user moves the slider).
            @scaler.signal_handler_block(@seek_handler)
            @scaler.value = (n or 0)
            @scaler.signal_handler_unblock(@seek_handler)

            # Move to the next track if completed.
            next_track if n == 1_000_000 
        end
    end
  
    def seek
	if @audiosink and total = @audiosink.query(Gst::QueryType::TOTAL, 
                                                   Gst::Format::TIME)
            # Compute the new nanosecond position.
            percent = @scaler.value / 10_000.0
            new_pos = (total * percent) / 100
    
            # Send the new position to the lastest sink pad.
            @pipeline.pause
            event = Gst::EventSeek.new(Gst::Format::TIME.to_i |
                                       Gst::EventSeek::METHOD_SET.to_i |
                                       Gst::EventSeek::FLAG_FLUSH.to_i,
                                       new_pos.to_i)
            @audiosink.send_event(event)
            @pipeline.play
        end
    end

    # Playlist methods:
    # -----------------
    
    def playlist
        if @playlist_box.visible?
            @playlist_box.hide
            self.resizable = false
        else
            @playlist_box.show
            self.resizable = true
        end
    end
    
    def refresh_playlist
        @model.clear
        @playlist.length.times do |i| 
            iter = @model.append
            iter.set_value(0, @playlist[i])
            # Highlight the current played track.
            if !@pipeline.stopped? and @current_track == i
                iter.set_value(1, "lightblue")
            end
        end 
    end

    def save_playlist
        dialog = Gtk::FileSelection.new("Save playlist as...")
        if dialog.run == Gtk::Dialog::RESPONSE_OK
            @playlist.save(dialog.filename) 
        end
        dialog.destroy
    end

    def clear_playlist
        stop unless @pipeline.stopped?
        @playlist.clear
        refresh_playlist
    end
    
    def load_files(clear_list_before = true)
        dialog = Gtk::FileSelection.new("Select files and/or playlist")
        dialog.select_multiple = true
        if dialog.run == Gtk::Dialog::RESPONSE_OK
            @pipeline.stop
            @playlist.clear if clear_list_before
            @playlist.add_files(dialog.selections)
            refresh_playlist
        end
        dialog.destroy
    end

    def remove_selected_track
        if iter = @listview.selection.selected
            if i = @playlist.index(iter.get_value(0))
                stop if @current_track == i
                @playlist.delete_at(i)
                refresh_playlist
            end
        end
    end
    
    # Misc methods:
    # -------------
   
    def popup_menu
        # Construct a popup menu with main actions.
        menu = Gtk::Menu.new
        @actions.each do |x| 
            menu.append(x ? x.to_menuitem : Gtk::MenuItem.new)
        end
        menu.show_all
        menu
    end
  
    def about
        Gnome::About.new(TITLE, VERSION,
                         "Copyright (C) 2003,2004 Ruby-GNOME2 Project Team",
                         "A Ruby-GNOME2 Audio Player",
                         [ "Laurent Sansonetti <lrz@gnome.org>" ], 
                         [], nil).show
    end
end

files = ARGV.collect { |x| x unless x =~ /^-/ }

Gnome::Program.new(Player::NAME,
                   Player::VERSION)
Gst.init
Player.new(files).show
Gtk.main
